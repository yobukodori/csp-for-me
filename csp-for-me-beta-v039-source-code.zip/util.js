const utilData = {};

function parseList(strList, delim = ",")
{
	var arList = [];
	if (typeof strList === "string" && strList){
		var ar = strList.split(delim);
		for (var i = 0 ; i < ar.length ; i++){
			var e = ar[i].trim();
			if (e)
				arList.push(e);
		}
	}
	return arList;
}

function onPrefersColorSchemeDarkChange(ev){
	if (utilData.colorScheme === "auto"){
		document.body.classList[ev.matches ? "add" : "remove"]("dark-mode");
	}
}

function setupColorScheme(colorScheme){
	utilData.colorScheme = colorScheme;
	if (colorScheme === "auto"){
		document.body.style.colorScheme = "light dark";
		document.body.classList[window.matchMedia("(prefers-color-scheme: dark)").matches ? "add" : "remove"]("dark-mode");
	}
	else {
		document.body.style.colorScheme = colorScheme;
		document.body.classList[colorScheme === "dark" ? "add" : "remove"]("dark-mode");
	}
}

function csp_normalize_source(src, directive)
{
	let r;
	if (directive === "plugin-types"){
		return src.toLowerCase();
	}
	else {
		if (/^'(none|self|unsafe-inline|unsafe-eval)'$/i.test(src))
			return src.toLowerCase();
		else if (r = src.match(/^'(nonce|sha256|sha384|sha512)-([a-z\d+\/]+={0,2})'$/i))
			return "'" + r[1].toLowerCase() + "-" + r[2] + "'";
		else if (r = src.match(/^([a-zA-Z][a-zA-Z\d+\-\.]*\:)$/))
			return src.toLowerCase();
		else if (r = src.match(/^([a-zA-Z][a-zA-Z\d+\-\.]*\:\/\/)?((\*\.)?[a-zA-Z\d][a-zA-Z\d\-]*(\.[a-zA-Z\d\-]+)*|\*)(\:(\d+|\*))?(\/.*)?/)){
			return (r[1]?r[1].toLowerCase():"")+r[2].toLowerCase()+(r[5]?r[5]:"")+(r[7]?r[7]:"");
		}
		else {
			//console.error("can't parse "+src);
			return src.toLowerCase();
		}
	}
}

const CSP_DIRECTIVE_REX = /^\s*(([a-zA-Z\d\-]+)(\s.*)?)?$/;

const ownDirectives = new Set(["no-csp", "create-csp"]);

function isOwnDirective(name){
	return ownDirectives.has(name);
}

function cspParse(csp_array){
	let ro = {policy:[]};
	let dir_names = {}, a = csp_array;
	for (let i = 0 ; i < a.length ; i++){
		let r = a[i].match(CSP_DIRECTIVE_REX);
		if (r){
			if (r[2]){
				let name = r[2].toLowerCase(), value = r[3] ? r[3] : "";
				if (dir_names[name] == null){
					dir_names[name] = i;
					let add = [], remove = [], removeDirective = false;
					value.split(" ").forEach(src=>{
						if (ro.error) return;
						if (src){
							let r = src.match(/^'remove':(.*)/i);
							if (r){
								if (! r[1]){
									ro.error = "'remove': has no argument: " + a[i];
									return;
								}
								let ss = r[1].split(",");
								ss.forEach(s=>{
									if (s.toLowerCase() == "'directive'")
										removeDirective = true;
									else if (/^\/.*\/$/.test(s )){
										try {
											remove.push(new RegExp(s.substring(1,s.length-1)));
										}
										catch(e){
											ro.error = e + " " + src + ": " + a[i];
											return;
										}
									}
									else if (s.length > 0)
										remove.push(csp_normalize_source(s));
								});
							}
							else {
								add.push(csp_normalize_source(src));
							}
						}
					});
					if (ro.error) return ro;
					ro.policy.push({
						name: name, 
						add: add, 
						remove: remove,
						removeDirective: removeDirective
					});
				}
			}
		}
		else {
			ro.error = "wrong CSP directive: " + a[i].substring(0,100);
			return ro;
		}
	}
	return ro;
}

function csp_policy2str(policy)
{
	let p = [];
	for (let i = 0 ; i < policy.length ; i++){
		let directive = policy[i], source = [];
		if (directive.removeDirective)
			source.push("'remove':'directive'");
		else {
			if (directive.remove.length > 0)
				source.push("'remove':" + directive.remove.join(","));
			directive.add.forEach(s=>source.push(s));
		}
		p.push((policy[i].name + " " + source.join(" ")).trim());
	}
	return p.join("; ");
}

function parseProfiles(profiles_str)
{
	let profile = [];
	profiles_str.split("\n").forEach((profileStr, n)=>{
		if (! /^[a-zA-Z]/.test(profileStr)) return;
		profileStr = profileStr.trim().replace(/\s+/g, ' ');
		let a = profileStr.split(";"), i = 0;
		let r = /^applied-urls(?:\s(.*))?$/.exec(a[i++]);
		if (! r){
			profile.push({ profileStr, error: "profile must start with applied-urls: " + profileStr});
			return;
		}
		let appliedUrls = r[1] || "", appliedTypes = "";
		if (r = /^\s*applied-types(?:\s(.*))?$/.exec(a[i])){
			appliedTypes = r[1] || "";
			i++;
		}
		profile.push({ profileStr, appliedUrls, appliedTypes, directives: a.slice(i) });
	});
	profile.forEach(prof =>{
		if (prof.error) return;
		prof.filterUrls = parseList(prof.appliedUrls);
		if (prof.filterUrls.length === 0){
			prof.error = "applied-urls has no url: " + prof.profileStr;
			return;
		}
		prof.filterTypes = parseList(prof.appliedTypes);
		let csp = cspParse(prof.directives);
		if (prof.error = csp.error) return;
		prof.text = `applied-urls ${prof.filterUrls.join(", ")};`
			+ (prof.filterTypes.length > 0 ? ` applied-types ${prof.filterTypes.join(", ")};` : "")
			+ " " + csp_policy2str(csp.policy);
		if (csp.policy.length === 0){
			prof.error = "profile has no policy: " + prof.text;
			return;
		}
		prof.policy = csp.policy;
		prof.removeHeaderIfExist = prof.policy.some(e => e.name === "no-csp");
		prof.createHeaderIfNotExist = prof.policy.some(e => e.name === "create-csp");
	});
	return { profile };
}

function cspMerge(csp_str, policy4me)
{
	let h = csp_str.split(",");
	if (h.length > 1){
		h = h.map(str => cspMerge(str, policy4me));
		return {
			modified: h.some(e => e.modified),
			policy: h.map(e => e.policy).filter(e => e).join(", "),
			log: h.map(e => e.log).filter(e => e).join(", "),
		};
	}
	let policy = [], dir_names = {};
	csp_str.split(";").forEach(directive=>{
		let r = directive.match(CSP_DIRECTIVE_REX);
		if (r && r[2]){
			let name = r[2].toLowerCase(), value = r[3] ? r[3] : "";
			if (dir_names[name] == null){
				let sources = [];
				value.split(" ").forEach(src=>{if (src) sources.push(csp_normalize_source(src));});
				dir_names[name] = policy.push({name: name, sources: sources}) - 1;
			}
		}
	});
	let modified, log = "";
	policy4me.forEach(directive=>{
		if (isOwnDirective(directive.name)) return;
		let pi = dir_names[directive.name], added = [], removed = [];
		if (pi != null){
			if (! directive.removeDirective){
				policy[pi].sources = policy[pi].sources.filter(src=>{
					for (let i = 0 ; i < directive.remove.length ; i++){
						let exp = directive.remove[i];
						if (exp instanceof RegExp ? exp.test(src) : exp === src){
							removed.push(src);
							return false;
						}
					}
					return true;
				});
				directive.add.forEach(src=>{
					if (! policy[pi].sources.includes(src)){
						policy[pi].sources.push(src);
						added.push(src);
					}
				});
				if (added.length + removed.length > 0){
					modified = true;
					log += " " + directive.name + (removed.length ? " -" + removed.join(" -") : "") + (added.length ? " +" + added.join(" +") : "") + ";";
				}
			}
			if (directive.removeDirective || policy[pi].sources.length === 0){
				policy.splice(pi, 1);
				Object.keys(dir_names).forEach(name=>{if (dir_names[name] > pi) --dir_names[name];});
				modified = true;
				log += " -" + directive.name + ";";
			}
		}
		else {
			if (directive.add.length > 0){
				policy.push({name: directive.name, sources: directive.add});
				modified = true;
				log += " +" + directive.name + (directive.add.length ? " "+directive.add.join(" ") : "")+";";
			}
		}
	});
	let a = [];
	policy.forEach(directive=>a.push(directive.name+" "+directive.sources.join(" ")));
	return {
		modified: modified,
		policy: a.length > 0 ? a.join(";") : "",
		log: log.trim()
	};
}

function cspCreate(policy4me)
{
	let policy = [];
	let modified, log = "";
	policy4me.forEach(directive=>{
		if (isOwnDirective(directive.name)) return;
		if (! directive.removeDirective){
			policy.push({name: directive.name, sources: directive.add});
			modified = true;
			log += " +" + directive.name + (directive.add.length ? " "+directive.add.join(" ") : "")+";";
		}
	});
	let a = [];
	policy.forEach(directive=>a.push(directive.name+" "+directive.sources.join(" ")));
	return {
		modified: modified,
		policy: a.length > 0 ? a.join(";") : "",
		log: log.trim()
	};
}
