let my = {
	os : "n/a", // mac|win|android|cros|linux|openbsd
	defaultTitle: "CSP for Me",
	initialized: null,
	settings: {},
	enableAtStartup: false,
    enabled : false,
	debug: false,
	noCache: false,
	profiles: "",
	profile: [],
	target: {
		"content-security-policy": 2,
		"content-security-policy-report-only": 1,
		"x-content-security-policy": 2,
		"x-content-security-policy-report-only": 1,
		"x-webkit-csp": 2
	},
	cacheTarget: {
		"cache-control": function(){
			return {
				name: "cache-control",
				value: "no-cache, no-store, must-revalidate"
			}
		},
		"expires": function(){
			return {
				name: "expires",
				value: new Date().toUTCString()
			}
		}
	},
	appliedCounter: 0,
	//====================================================
    init : function(platformInfo) 
	{
		my.initialized = new Promise((resolve, reject)=>{
			try {
				let man = browser.runtime.getManifest();
				if (man.browser_action && man.browser_action.default_title)
					my.defaultTitle = man.browser_action.default_title;
				my.os = platformInfo.os;

				browser.browserAction.onClicked.addListener(function(){
					my.toggle();
				});
				my.updateButton();
				browser.runtime.onMessage.addListener(my.onMessage);

				browser.storage.sync.get(["enableAtStartup","printDebugInfo","noCache","colorScheme","appliedUrls",'appliedPolicy',"profiles"])
				.then((pref) => {
					if (typeof pref.profiles !== "string"){
						//pref.appliedUrls = "*://twitter.com/*, *://mobile.twitter.com/*";
						//pref.appliedPolicy = "script-src 'remove':/^'(nonce|sha256|sha384|sha512)-/ 'unsafe-inline'; report-uri 'remove':'directive'";
						if (pref.appliedUrls || pref.appliedPolicy){
							pref.profiles = "# In version 0.3.9, multiple profiles can now be written. The settings data has been converted to comply with the specification changes.\n"
								+ "# For details, see https://addons.mozilla.org/firefox/addon/csp-for-me/\n"
								+ "applied-urls " + (pref.appliedUrls || "") + "; " + (pref.appliedPolicy || "");
						}
					}
					my.updateSettings(pref, pref.enableAtStartup);
					resolve();
				})
				.catch(err=>{
					reject(err);
				});
			}
			catch(e){
				reject(e.message);
			}
		});
    },
	//====================================================
	updateSettings : function(pref, fEnable)
	{
		my.settings = pref;
		let disabled;
		my.enableAtStartup = pref.enableAtStartup || false;
		my.debug = pref.printDebugInfo || false;
		my.noCache = pref.noCache || false;
		if (typeof pref.profiles === "string"){
			if (pref.profiles !== my.profiles){
				if (my.enabled){
					my.toggle(false);
					disabled = true;
				}
				my.profiles = pref.profiles;
				let ro = parseProfiles(my.profiles);
				if (ro.error || ro.profile.some(prof => prof.error)){
					if (ro.error){
						my.log("error: " + ro.error);
					}
					else {
						ro.profile.forEach((prof, i)=>{
							if (prof.error){
								my.log("error: " + prof.error);
							}
						});
					}
					my.profile = [];
				}
				else {
					my.profile = ro.profile;
					my.profile.forEach(prof => prof.onHeadersReceived = my.onHeadersReceived.bind(prof));
					my.log("profiles " + (my.profile.length === 0 ? "cleared" : "changed\n  " + my.profile.map((prof, i) => `profile[${i}] ${prof.text}`).join("\n  ")));
				}
			}
		}
		if (disabled || (fEnable && ! my.enabled)){
			if (my.profile.length > 0)
				my.toggle(true);
		}
	},
	//====================================================
	log : function(str)
	{
		browser.runtime.sendMessage({type:"log",str:str}).catch(err=>{});
	},
	//====================================================
	onMessage : function(message, sender, sendResponse)
	{
		if (message.type === "getStatus"){
			browser.runtime.sendMessage({
				type: "status",
				"status": {
					enabled: my.enabled,
					debug: my.debug,
					noCache: my.noCache,
					profiles: my.profiles,
					//profile: my.profile,
					appliedCounter: my.appliedCounter
				}
			});
		}
		else if (message.type === "getSettings"){
			if (my.initialized){
				my.initialized.then(()=>{
					sendResponse({
						enableAtStartup: my.enableAtStartup,
						printDebugInfo: my.debug,
						noCache: my.noCache,
						colorScheme: my.settings.colorScheme,
						profiles: my.profiles,
					});
				})
				.catch(err=>{
					sendResponse({
						error: err,
					});
				});
				return true;
			}
			else {
				sendResponse({
					error: "background.js has not been initialized yet.",
				});
			}
		}
		else if (message.type === "updateSettings"){
			my.updateSettings(message.pref);
		}
		else if (message.type === "toggle"){
			my.toggle();
		}
		else if (message.type === "getEnabled"){
			sendResponse({
				enabled: my.enabled,
				canEnable: my.profile.length > 0,
			});
		}
	},
	//====================================================
    toggle : function(state) 
	{
        if(typeof state === 'boolean') {
            my.enabled = state;
        }
        else {
			if (my.enabled = ! my.enabled){
				if (my.profile.length === 0){
					my.enabled = false;
					my.log("Error: profile not applied");
					return;
				}
			}
        }

        my.updateButton();

        if(my.enabled) {
			my.profile.forEach((prof, i)=>{
				let filter = {urls: prof.filterUrls};
				prof.filterTypes.length > 0 && (filter.types = prof.filterTypes);
				browser.webRequest.onHeadersReceived.addListener(
					prof.onHeadersReceived
					,filter
					,["blocking" ,"responseHeaders"]
				);
			});
        }
        else {
			my.profile.forEach((prof, i)=>{
				browser.webRequest.onHeadersReceived.removeListener(
					prof.onHeadersReceived
				);
			});
        }
		browser.runtime.sendMessage({type:"statusChange", enabled:my.enabled })
		.catch(e=>{});
    },
	//====================================================
    updateButton : function() 
	{
        let buttonStatus = my.enabled ? 'on' : 'off';
		if (browser.browserAction.setIcon !== undefined)
			browser.browserAction.setIcon({path:{48:'icons/button-48-'+buttonStatus+'.png'}});
		if (browser.browserAction.setTitle !== undefined)
			browser.browserAction.setTitle({title: my.defaultTitle});
    },
	//====================================================
    onHeadersReceived : function(response) 
	{
		function header2str(h){
			return h.name+": "+h.value;
		}
		let urlReported, modified, enforced;
		for (let i = response.responseHeaders.length - 1 ; i >= 0 ; i--){
			let target = my.target[response.responseHeaders[i].name.toLowerCase()];
			if (target > 0){
				target === 2 && (enforced = true);
				if (! urlReported){
					if (my.debug) my.log("["+response.type+"] " + response.url.substring(0,60));
					urlReported = true;
				}
				if (my.debug) my.log(header2str(response.responseHeaders[i]));
				if (this.removeHeaderIfExist){
					modified = true;
					if (my.debug) my.log("Removed: " + response.responseHeaders[i].name);
					response.responseHeaders.splice(i, 1);
				}
				else {
					let ro = cspMerge(response.responseHeaders[i].value, this.policy);
					if (ro.modified){
						modified = true;
						if (ro.policy){
							if (my.debug){
								my.log("Modified: " + ro.log);
								my.log("Replaced with: " + ro.policy);
							}
							response.responseHeaders[i].value = ro.policy;
						}
						else { // All directives were removed.
							if (my.debug){
								my.log("Modified: " + ro.log);
								my.log("Removed: " + response.responseHeaders[i].name);
							}
							response.responseHeaders.splice(i, 1);
						}
					}
				}
			}
		}
		if (this.createHeaderIfNotExist && (this.removeHeaderIfExist || ! enforced)){
			if (! urlReported){
				if (my.debug) my.log("["+response.type+"] " + response.url.substring(0,60));
				urlReported = true;
			}
			let ro = cspCreate(this.policy);
			if (ro.modified){
				modified = true;
				if (ro.policy){
					const headerName = "content-security-policy";
					if (my.debug){
						my.log("Created: " + headerName + ": " + ro.policy);
					}
					response.responseHeaders.push({ name: headerName, value: ro.policy });
				}
			}
		}
		
		if (my.noCache && modified){
			for (let i = response.responseHeaders.length - 1 ; i >= 0 ; i--){
				if (my.cacheTarget[response.responseHeaders[i].name.toLowerCase()]){
					if (my.debug) my.log("Removed: "+header2str(response.responseHeaders[i]));
					response.responseHeaders.splice(i, 1);
				}
			}
			Object.keys(my.cacheTarget).forEach(function(name){
				let i = response.responseHeaders.push(my.cacheTarget[name]()) - 1;
				if (my.debug) my.log("Added: "+header2str(response.responseHeaders[i]));
			});
		}
		
		//let BlockingResponse = {};
		if (modified){
			my.appliedCounter++;
			return {responseHeaders: response.responseHeaders};
		}
    }
};

browser.runtime.getPlatformInfo().then(my.init);
